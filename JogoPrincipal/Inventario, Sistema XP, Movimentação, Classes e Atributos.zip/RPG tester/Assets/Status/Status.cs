﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Status : MonoBehaviour {
    private float experiencia=0;
    private float influencia=0;
    private Transform Heroi;

    /*ATRIBUTOS*/
    private int forca;
    private int destreza;
    private int inteligencia;
    private int constituição;

    /*STATUS*/
    public float vida= 200;
    public float stamina = 100;
    public float dano = 100 ;
    public float danoQuimico = 50;
    public float defesa = 50;

    /*OBJETOS*/
    //elmo
    //peito
    //luva
    //calça
    //bota
    //arma
    private 


    void Start()
    {
        //O personagem deve começar com certo status; definir status de inicio.
    }	
	void Update () {


		
	}
}
