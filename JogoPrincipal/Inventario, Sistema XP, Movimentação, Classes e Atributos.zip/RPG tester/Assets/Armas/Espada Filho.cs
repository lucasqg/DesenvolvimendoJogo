﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EspadaFilho : Espadas {
    private string classePersonagem;
    private EspadaFilho[] espada = new EspadaFilho[30];
    private int i=0;    // cada i refere-se a uma espada diferente 

  

    public EspadaFilho(string classe, int nvl, int forM, int desM, int dn, float vel, int
        critc, int danoTot) : base(classe,nvl,forM,desM,dn,vel,critc, danoTot)
    {
    }

    void Start () {
        gerarEspadas();
	}
	
	
	void Update () {
		
	}

    public void gerarEspadas()
    {
         espada[0] = new EspadaFilho(classePersonagem, 1, 0, 0, 0, 0, 0, 20); //espada inicial
         espada[1] = new EspadaFilho(classePersonagem, 1, 0, 0, 8, 0.1f, 0, 20); //drop monstro
         espada[2] = new EspadaFilho(classePersonagem, 1, 0, 0, 16, 0.2f, 0, 20); //
         espada[3] = new EspadaFilho(classePersonagem, 1, 0, 0, 32, 0.3f, 0, 20);
         espada[4] = new EspadaFilho(classePersonagem, 1, 0, 0, 64, 0.4f, 0, 20);



    }


}
