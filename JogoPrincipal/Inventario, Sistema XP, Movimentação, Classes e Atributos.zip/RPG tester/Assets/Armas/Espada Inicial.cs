﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EspadaInicial : MonoBehaviour {
    private string nomeEspada = "espadaInicial";
    private string classe = "espadachin";
    private int nvlMin = 1;
    private int forca = 20;
    private int des = 10;
    private int dano = 50;
    
	void Start () {
        
	}
	
	
	void Update () {
		
	}

    /* MÉTODOS GETTERS */

    public float getNvlMin()
    {
        return nvlMin;
    }
    public float getForca()
    {
        return forca;
    }
    public float getDes()
    {
        return des;
    }
    public float getDano()
    {
        return dano;
    }
    public string getNomeEspada()
    {
        return nomeEspada;
    }
    public string getClasse()
    {
        return classe;
    }

}
