﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Espadas : MonoBehaviour {
    private int dano, forMin, desMin, nivel, danoTotal;
    private int critico;
    private float velAttack;
    private string classe = "guerreiro";
    private string classeCompara;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    /*MÉTODO CONSTRUTOR*/
    public Espadas(string classeP, int nvl, int forM, int desM, int dn, float vel, int critic, int danoTot)
    {
        this.dano = dn;
        this.velAttack = vel;
        this.forMin = forM;
        this.desMin = desM;
        this.critico = critic;
        this.classeCompara = classeP;
        this.nivel = nvl;
        this.danoTotal = danoTot;
    }

    /*MÉTODOS GET*/

    public int getDano()
    {
        return dano;
    }
    public float getVelAttack()
    {
        return velAttack;
    }
    public int getForMin()
    {
        return forMin;
    }
    public int getDesMin()
    {
        return desMin;
    }
    public int getCritico()
    {
        return critico;
    }
    public int getNivel()
    {
        return nivel;
    }

    /*MÉTODOS SET*/

    public void setDano(int dano)
    {
        this.dano = dano;
    }
    public void setVelAttack(float velAttack)
    {
        this.velAttack = velAttack;
    }
    public void setForMin(int forMin)
    {
        this.forMin = forMin;
    }
    public void setDesMin(int desMin)
    {
        this.desMin = desMin;
    }
    public void setCritico(int critico)
    {
        this.critico = critico;
    }
    public void setNivel(int nivel)
    {
        this.nivel = nivel;
    }
    public void setDanoTotal(int danoT)
    {
        this.danoTotal = danoT;
    }
}
