﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Andar : MonoBehaviour {
    private float vel = 2f;
    public Transform player;

	// Use this for initialization
	void Start () {
        player = GetComponent<Transform>();
    }
	
	// Update is called once per frame
	void Update () {
       // if (vivo == true)
        //{
            if (Input.GetKey(KeyCode.D))
            {
                transform.Translate(new Vector2(vel * Time.deltaTime, 0));
               // anim.SetBool("Parada", false);
                //anim.SetBool("Andar", true);
            }
            if (Input.GetKey(KeyCode.A))
            {
                transform.Translate(new Vector2(-vel * Time.deltaTime, 0));
              //  anim.SetBool("Parada", false);
              //  anim.SetBool("Andar", true);
            }
            if (Input.GetKey(KeyCode.W))
            {
               transform.Translate(new Vector2(0, vel * Time.deltaTime));
               //  anim.SetBool("Parada", false);
               //  anim.SetBool("Andar", true);
            }
            else if (Input.GetKey(KeyCode.S))
            {
                transform.Translate(new Vector2(0, -vel * Time.deltaTime));
                //  anim.SetBool("Parada", false);
                //  anim.SetBool("Andar", true);
            }
        /* else
         {
             anim.SetBool("Parada", true);
             anim.SetBool("Andar", false);
         }*/
        // }
    }
}
