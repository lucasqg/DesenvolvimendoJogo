﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class BasicStats
{
    public float startLife; //vida inicial
    public float startStamina;
    public int forca;
    public int inteligencia;
    public int precisão;
    public int baseDefense;
    public int baseAttack;
}

public abstract class CharacterBase : MonoBehaviour {
    public int currentLevel;
    public BasicStats basicStats;

    
     

	// Use this for initialization
	protected void Start () {
		
	}

    // Update is called once per frame
    protected void Update () {
		
	}
}
