﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIController : MonoBehaviour {
    public ContoleDeInventario inventario;
    public float defaultTimeScale;
	// Use this for initialization
	void Start () {
        inventario.gameObject.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.I))
        {
            inventario.gameObject.SetActive(!inventario.gameObject.activeSelf); // liga e desliga o inventario

            if (inventario.gameObject.activeSelf)//CONDICIONAL QUE PAUSE O GAME.
            {
                Time.timeScale = 0;
            }
            else
            {
                Time.timeScale = defaultTimeScale;
            }
        }
	}
}
