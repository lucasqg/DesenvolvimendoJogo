﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum TypeCharacter
{
    Guerreiro=0, 
    Bomber=1,
    Pistoleiro=2
}
public class PlayerBehaviour : CharacterBase {
    private TypeCharacter type;

	// Use this for initialization
	protected void Start () {
        base.Start();
        currentLevel = PlayerStatsController.GetCurrentLevel();
        type = PlayerStatsController.GetTypeCharacter();

        basicStats = PlayerStatsController.instance.GetBasicStatsPlayer(type);
    }
	

	// Update is called once per frame
	void Update () {
		
	}
}
