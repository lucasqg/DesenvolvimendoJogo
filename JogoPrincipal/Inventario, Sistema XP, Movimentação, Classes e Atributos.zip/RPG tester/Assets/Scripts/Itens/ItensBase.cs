﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItensBase : MonoBehaviour {
    public string nameItem;
    public Sprite icon;
    public bool isStacklabe;
    protected int amount = 1 ;

	public void addItem(int amountToAdd = 1)
    {
        amount += amountToAdd;
    }
    public int getAmount()
    {
        return amount;
    }
}
