﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Equipamentos : MonoBehaviour {
    private Material elmo, peito, calça, luva, bota;
    private Material espada, pistola, bomba;
    private Material brinco1, brinco2, colar;
	
	void Start () {
		
	}
	
	
	void Update () {
		
	}
}
