﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class DestructiveBase : MonoBehaviour {
    public float currentLife;

	void Start () {
        

    }
	
	void Update () {
		
	}

    public void ApplayDamage(int damage)
    {
        currentLife -= damage;
        if (currentLife <= 0)
        {
            OnDestroyed();
        }
    }

    public abstract void OnDestroyed();
} 
