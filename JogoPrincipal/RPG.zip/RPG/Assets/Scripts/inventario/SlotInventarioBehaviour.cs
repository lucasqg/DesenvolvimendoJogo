﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SlotInventarioBehaviour : MonoBehaviour {

    public ItensBase currentItem;
    public Image iconItemSlot;
    public Text nameItem;
    public GameObject AmountIndicator;
    public Text amountText;
     
	// Use this for initialization
	void Start () {
        SetupSlot();

    }
	
    public void SetupSlot()
    {
        if(currentItem != null)
        {
            SetActiveSlot(true);
            iconItemSlot.sprite = currentItem.icon;
            nameItem.text = currentItem.nameItem;

            if (currentItem.isStacklabe)
            {
                amountText.text = currentItem.getAmount().ToString(); 
            }
            else
            {
                AmountIndicator.SetActive(false);
            }
        }
        else
        {
            SetActiveSlot(false);
        }
    }

    public void SetActiveSlot(bool isActive=true)
    {
        AmountIndicator.SetActive(isActive);
        nameItem.gameObject.SetActive(isActive);
        iconItemSlot.gameObject.SetActive(isActive);
    }

	// Update is called once per frame
	void Update () {
		
	}

    private void OnEnable()
    {
        SetupSlot();
    }
}
