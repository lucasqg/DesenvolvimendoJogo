﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 
public class ContoleDeInventario : MonoBehaviour
{
    public List<SlotInventarioBehaviour> InventarioSlots;
    public static ContoleDeInventario instance;
    public int maxInventarioSlots=20;
    public SlotInventarioBehaviour slotPrefab;
    public Transform itensGrid;
    void Start()
    {
        instance = this;

        for(int i =0; i< maxInventarioSlots; i++)
        {
            GameObject tempSlot = Instantiate(slotPrefab.gameObject);
            tempSlot.transform.SetParent(itensGrid, false);
            InventarioSlots.Add(tempSlot.GetComponent<SlotInventarioBehaviour>());
        }
    }

   
    void Update()
    {

    }

    public void AddItemToInventory(ItensBase item)
    {
        bool foundItem = false;
        SlotInventarioBehaviour slotVazio = proxSlotVazio();
        if (item.isStacklabe )
        {
            foreach(SlotInventarioBehaviour slot in InventarioSlots)
            {
                if(slot.currentItem!=null && slot.currentItem.nameItem == item.nameItem)
                {
                    slot.currentItem.addItem();
                    foundItem = true;
                }
            }
            if (!foundItem && slotVazio !=null)
            {
                slotVazio.currentItem = item;
            }
        }
        else if(slotVazio != null)
        {
            slotVazio.currentItem = item;
        }
        
        item.gameObject.SetActive(false);
    }

    private SlotInventarioBehaviour proxSlotVazio()
    {
        SlotInventarioBehaviour slotToReturn = null;
        foreach (SlotInventarioBehaviour slot in InventarioSlots)
        {
            if(slot.currentItem == null)
            {
                slotToReturn =  slot;
                break;
            }
        }
        return slotToReturn;
    }
}
