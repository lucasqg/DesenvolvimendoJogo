﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PotionBehaviour : ItensBase {

    public float amountLiquid;

}
