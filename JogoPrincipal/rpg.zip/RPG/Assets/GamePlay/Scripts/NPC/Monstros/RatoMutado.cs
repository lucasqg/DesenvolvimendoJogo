﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RatoMutado : NpcBase {

	// Use this for initialization
	void Start () {
        danoTotal = 30;
        defesaTotal = 40;
        totalLife = 120;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
