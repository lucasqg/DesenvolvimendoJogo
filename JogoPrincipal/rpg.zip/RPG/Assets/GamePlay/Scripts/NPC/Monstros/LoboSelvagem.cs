﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoboSelvagem : NpcBase {

	// Use this for initialization
	protected void Start () {
        basicStats.baseAttack = 10;
        basicStats.baseDefense = 20;
        basicStats.startLife = 50;
        basicStats.nameNpc = "LoboSelvagem";
	}
	
	
	void Update () {
		
	}


}
